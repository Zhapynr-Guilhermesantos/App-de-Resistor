import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';

const ResistorcorCode = ({navigation}) => {
  const [valorResistencia, setValorResistencia] = useState("");
  const [corDigito, setCorDigito] = useState([]);
  const [corMultiplicador, setCorMultiplicador] = useState([]);
  {/* criando construtor */}
  
  {/* criando 3 maps/arrays de cada cor com seus valores */}
  const corDigitoMap = {
    0: 'black',
    1: 'brown',
    2: 'red',
    3: 'orange',
    4: 'yellow',
    5: 'green',
    6: 'blue',
    7: 'purple',
    8: 'gray',
    9: 'white',
  };

  const corMultiplicadorMap = {
    '': 'black',
    '0': 'brown',
    '00': 'red',
    '000': 'orange',
    '0000': 'yellow',
    '00000': 'green',
    '000000': 'blue',
    '0000000': 'purple',
    '00000000': 'gray',
    '000000000': 'white',
  };

  const corAcessibilidadeMap = {
    black: 'Preto',
    brown: 'Marrom',
    red: 'Vermelho',
    orange: 'Laranja',
    yellow: 'Amarelo',
    green: 'Verde',
    blue: 'Azul',
    purple: 'Roxo',
    gray: 'Cinza',
    white: 'Branco',
  };

  const calcularCor = () => {
    if(valorResistencia.charAt(0) == 0){
      return alert("Erro: Não pode iniciar o valor com '0'");
    } else if (valorResistencia.length >= 3){
    digitos = valorResistencia.slice(0, 2).split("");
    multiplicador = valorResistencia.slice(2);
    } else if (valorResistencia.length >= 2){
      digitos = valorResistencia.slice(0, 2).split("");
      multiplicador = '';
    } else if (valorResistencia.length == 1 || valorResistencia.length == 0){
     return alert("Erro");
    } 
    {/* if elses para tratar errors de entrada de input como 0 no inicio, numeros não aplicaveis.Além disso, criando array/string armazenando os dados coletados do valorResistencia, digitos armazenando os 2 primeiros numeros e multiplicador armazenando os restantes */}

    const coresDigitos = digitos.map(digit => {
      const corNome = corAcessibilidadeMap[corDigitoMap[digit]];
      return { cor: corDigitoMap[digit], nome: corNome };
    });
    {/* usando map para rodar sobre o array digitos e passando cada digito do array pelo const corNome para identificar o nome da cor e dando um return criando um objeto que tem cor e nome */}

    const multiplicadorCor = {
      cor: corMultiplicadorMap[multiplicador],
      nome: corAcessibilidadeMap[corMultiplicadorMap[multiplicador]],
    };
    {/* como aqui é só uma string, a identificação de cor e nome da cor já são diretamente feitos */}

    setCorDigito(coresDigitos);
    setCorMultiplicador([multiplicadorCor]);
    {/* salvando os resultados das identificações */}
    
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Calculadora de Resistores</Text>
      <View style={styles.container2}>
      <View style={styles.buttons}>
      <TouchableOpacity style={styles.button1} onPress={() => navigation.navigate('Tela1')}>
      {/* Nevaga para a tela1 */}
          <Text style={{ color: 'white' }}> COR => VALOR </Text>
    </TouchableOpacity>

    <TouchableOpacity style={styles.button2}>
                <Text style={{ color: 'white' }}> VALOR => COR </Text>
     </TouchableOpacity>

      </View>
      <TextInput
        style={styles.input}
        placeholder="Digite o valor da resistência"
        keyboardType="numeric"
        value={valorResistencia}
        onChangeText={(text) => setValorResistencia(text)}
      />
      {/* Recebe o valor de valorResistencia */}

      <TouchableOpacity
        style={styles.button}
        onPress={calcularCor}
      >
        <Text style={styles.buttonText}>Calcular Cores</Text>
      </TouchableOpacity>
      {/* inicializa a função */}

      <View style={styles.coloCodeContainer}>
        <Text style={styles.colorCodeLabel}>Dígitos:</Text>
        {corDigito.map((item) => (
          <View style={[styles.colorBox, { backgroundColor: item.cor.toLowerCase() }]}>
            <Text style={styles.colorText}>{item.nome}</Text>
            <Text style={styles.colorText2}>{item.nome}</Text>
          </View> 
        ))} {/* manualmente estiliza o view e os Texts com a cor e nome respectivamente */}
      </View>

      <View style={styles.coloCodeContainer}>
        <Text style={styles.colorCodeLabel}>Multiplicador:</Text>
        {corMultiplicador.map((item) => (
          <View style={[styles.colorBox, { backgroundColor: item.cor.toLowerCase()}]}>
            <Text style={styles.colorText}>{item.nome}</Text>
            <Text style={styles.colorText2}>{item.nome}</Text>
          </View>
        ))} {/* manualmente estiliza o view e os Texts com a cor e nome respectivamente */}
      </View>
    </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#13678A',
    height: 670,
  },
  container2: {
    width: '100%',
    height: '100%',
    display: 'flex',
    flexdirection:'column',
    justifyContent: 'center',
    backgroundColor: '#13678A', 
    padding: 10,
    paddingBottom: 20,
  },

  title: {
    backgroundColor: '#012030',
    borderRadius: 5,
    borderStyle: 'solid',
    borderWidth: 1,
    borderColor: 'white',
    textAlign: 'center',
    lineHeight: 60,
    fontSize: 20,
    fontWeight: 'bold',
    fontFamily: 'arial',
    color: 'white',
  },
  input: {
    width: 200,
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 20,
    marginTop: 45, // Adicione margem à parte superior
    paddingLeft: 10,
    color: 'white',
    alignSelf: 'center', // Centralizar horizontalmente
    justifyContent: 'center',
  },
  button: {
    backgroundColor: '#4CAF50', // cor Verde 
    padding: 10,
    borderRadius: 5,
    marginBottom: 20,
  },
  
  button1: {
    backgroundColor: '#004e98', 
    width: 130,
    height: 40,
    textAlign: 'center',
    justifyContent: 'center',
    marginTop: -30, 
    borderRadius: 7,
  },

 button2: {
    backgroundColor: '#0a0908', // cor AZUL
    width: 130,
    height: 40,
    textAlign: 'center',
    justifyContent: 'center',
    marginTop: -30, 
    borderRadius: 7,
  },

  buttons: {
    flexDirection: 'row',
    justifyContent: 'space-evenly',
  },
  
  buttonText: {
    color: 'white',
    textAlign: 'center',
  },
  coloCodeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
  },
  colorCodeLabel: {
    marginRight: 10,
    color: 'white',
  },
  colorBox: {
    width: 100,
    height: 60,
    margin: 5,
    borderRadius: 5,
    color: 'white',
    justifyContent: 'center',
    alignItems: 'center',
  },
  colorText: {
    color: 'black',
  },
  colorText2: {
    color: 'white',
  },

});

export default ResistorcorCode;

