import {View, Text, SafeAreaView, StyleSheet, TouchableOpacity } from 'react-native';
import React, { useState } from 'react';
import { Picker } from '@react-native-picker/picker';

 const App = ({navigation}) => {
   const [primeiraCor, setPrimeiraCor] = useState();
   const [segundaCor, setSegundaCor] = useState();
   const [terceiraCor, setTerceiraCor] = useState();
   {/* criando o construtor */}

  return (
    <View style={styles.container3}>
     <Text style={styles.paragraph}>
        Calculadora de Resistores
      </Text>
    <View style={styles.container}>
    <View style={styles.selects}>
    <TouchableOpacity style={styles.button1}>
          <Text style={{ color: 'white' }}> COR => VALOR </Text>
    </TouchableOpacity>
    {/* Butão que leva a Segunda tela */}
    <TouchableOpacity style={styles.button2} onPress={() => navigation.navigate('Tela2')}>
                <Text style={{ color: 'white' }}> VALOR => COR </Text>
     </TouchableOpacity>
    </View>
    <View>
       <Text style={styles.titulo2}> Selecione as Cores</Text>
    </View>

    <View style={styles.buttons}>
    {/* 3 Pickers para selecionar as cores */}
    <Picker
  selectedValue={primeiraCor}
  onValueChange={(itemValue) =>
    setPrimeiraCor(itemValue)
  } style={styles.select1}>
  <Picker.Item label="Selecionar" value="" />
  <Picker.Item label="Marrom" value="1" />
  <Picker.Item label="Vermelho" value="2" />
  <Picker.Item label="Laranja" value="3" />
  <Picker.Item label="Amarelo" value="4" />
  <Picker.Item label="Verde" value="5" />
  <Picker.Item label="Azul" value="6" />
  <Picker.Item label="Roxo" value="7" />
  <Picker.Item label="Cinza" value="8" />
  <Picker.Item label="Branco" value="9" />
</Picker>

    <Picker
  selectedValue={segundaCor}
  onValueChange={(itemValue) =>
    setSegundaCor(itemValue)
  } style={styles.select2}>
  <Picker.Item label="Selecionar" value="" />
  <Picker.Item label="Preto" value="0" />
  <Picker.Item label="Marrom" value="1" />
  <Picker.Item label="Vermelho" value="2" />
  <Picker.Item label="Laranja" value="3" />
  <Picker.Item label="Amarelo" value="4" />
  <Picker.Item label="Verde" value="5" />
  <Picker.Item label="Azul" value="6" />
  <Picker.Item label="Roxo" value="7" />
  <Picker.Item label="Cinza" value="8" />
  <Picker.Item label="Branco" value="9" />
</Picker>

    <Picker
  selectedValue={terceiraCor}
  onValueChange={(itemValue) =>
    setTerceiraCor(itemValue)
  } style={styles.select3}>
  <Picker.Item label="Selecionar" value="" />
  <Picker.Item label="Preto" value="" />
  <Picker.Item label="Marrom" value="0" />
  <Picker.Item label="Vermelho" value="00" />
  <Picker.Item label="Laranja" value="000" />
  <Picker.Item label="Amarelo" value="0000" />
  <Picker.Item label="Verde" value="00000" />
  <Picker.Item label="Azul" value="000000" />
  <Picker.Item label="Roxo" value="0000000" />
  <Picker.Item label="Cinza" value="00000000" />
  <Picker.Item label="Branco" value="000000000" />
</Picker>
    </View>
          {/* caixa de resultado que imprime os numeros/valores de cada cor selecionada */}
          <View style={styles.resultContainer}>
          <Text style={styles.resultLabel}>Resultado</Text>
          <View style={styles.resultBox}>
            <Text style={styles.resultText}>{primeiraCor}{segundaCor}{terceiraCor}</Text>
          </View>
        </View>
    </View>
    </View>
  
  );
}



const styles = StyleSheet.create({
  selects: {
    flexDirection: 'row',
    justifyContent: 'space-evenly',

  },
  buttons: {
    width: 300,
    height: 180,
    flexDirection: "column",
    flexWrap: 'wrap',
    justifyContent: 'space-evenly',

  },
  select1: {  
    padding: 4,
    width: 100,
    backgroundColor: 'rgba(255, 255, 255, 0.95)', // Branco com 95% de transparência',
    alignSelf: 'center',
    borderRadius: 6,

  },
  select2: {
    padding: 4,
    width: 100,
    backgroundColor: 'rgba(255, 255, 255, 0.95)', // Branco com 95% de transparência',
    alignSelf: 'center',
    borderRadius: 6,

    
  },
  select3: {
    padding: 4,
    width: 100,
    backgroundColor: 'rgba(255, 255, 255, 0.95)', // Branco com 95% de transparência',
    alignSelf: 'center',
    borderRadius: 6,
},
  button1: {
    backgroundColor: '#0a0908', 
    width: 130,
    height: 40,
    textAlign: 'center',
    justifyContent: 'center',
    marginTop: -30, 
    borderRadius: 7,

  },
  button2: {
    backgroundColor: '#004e98', // cor AZUL
    width: 130,
    height: 40,
    textAlign: 'center',
    justifyContent: 'center',
    marginTop: -30, 
    borderRadius: 7,

  },

  container: {
    width: '100%',
    height: '100%',
    display: 'flex',
    flexdirection:'column',
    justifyContent: 'center',
    backgroundColor: '#13678A', 
    padding: 10,
    paddingBottom: 20,
  },

  container3: {
    backgroundColor: '#13678A',
    height: 670,
  },

  paragraph: {
    backgroundColor: '#012030',
    borderRadius: 5,
    borderStyle: 'solid',
    borderWidth: 1,
    borderColor: 'white',
    textAlign: 'center',
    lineHeight: 60,
    fontSize: 20,
    fontWeight: 'bold',
    fontFamily: 'arial',
    color: 'white',
    
  },
  resultContainer: {
    alignItems: 'center',
    marginTop: 50,
  },
  resultLabel: {
    backgroundColor: '#012030',
    borderRadius: 5,
    borderStyle: 'solid',
    borderWidth: 1,
    borderColor: 'white',
    textAlign: 'center',
    lineHeight: 35,
    width: 90,
    height: 35,
    fontSize: 15,
    fontWeight: 'bold',
    fontFamily: 'arial',
    color: 'white',

  },
  resultBox: {
    borderWidth: 1,
    borderColor: 'white',
    padding: 8,
    borderRadius: 5,
    alignItems: 'center',
    marginTop: 15, 

  },
  resultText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 10, 

  },
  titulo2: {
    backgroundColor: '#012030',
    borderRadius: 5,
    borderStyle: 'solid',
    borderWidth: 1,
    borderColor: 'white',
    textAlign: 'center',
    lineHeight: 25,
    fontSize: 15,
    fontWeight: 'bold',
    fontFamily: 'arial',
    color: 'white',
    marginTop: 20,

  },
});

export default App